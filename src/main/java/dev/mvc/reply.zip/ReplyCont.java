package dev.mvc.reply;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reply")
public class ReplyCont {

  @Autowired
  @Qualifier("replyProc")
  private ReplyProcInter replyProc;

  /**
   * 댓글 목록 + 등록 폼
   */
  @GetMapping("/list_by_contentsno")
  public String list_by_contentsno(@RequestParam("dogcontno") int dogcontno, Model model) {
    List<ReplyVO> list = this.replyProc.list_by_contentsno(dogcontno);
    model.addAttribute("list", list);
    model.addAttribute("dogcontno", dogcontno);
    return "reply/list_all";  // calendar 스타일의 list_all.html
  }

  /**
   * 댓글 등록
   */
  @PostMapping("/create")
  public String create(ReplyVO replyVO, Model model) {
    int cnt = this.replyProc.create(replyVO);
    if (cnt == 1) {
      this.replyProc.increaseReplycnt(replyVO.getDogcontno());
      model.addAttribute("msg", "댓글이 등록되었습니다.");
    } else {
      model.addAttribute("msg", "댓글 등록에 실패했습니다.");
    }

    model.addAttribute("url", "/reply/list_by_contentsno?dogcontno=" + replyVO.getDogcontno());
    return "reply/msg";  // calendar 스타일의 메시지 뷰
  }

  /**
   * 댓글 수정 폼
   */
  @GetMapping("/update_form")
  public String update_form(@RequestParam("replyno") int replyno, Model model) {
    ReplyVO replyVO = this.replyProc.read(replyno);
    model.addAttribute("replyVO", replyVO);
    return "reply/update";  // calendar 스타일의 수정 페이지
  }

  /**
   * 댓글 수정 처리
   */
  @PostMapping("/update")
  public String update(ReplyVO replyVO, Model model) {
    int cnt = this.replyProc.update(replyVO);
    if (cnt == 1) {
      model.addAttribute("msg", "댓글이 수정되었습니다.");
    } else {
      model.addAttribute("msg", "댓글 수정에 실패했습니다.");
    }

    model.addAttribute("url", "/reply/list_by_contentsno?dogcontno=" + replyVO.getDogcontno());
    return "reply/msg";
  }

  /**
   * 댓글 삭제
   */
  @GetMapping("/delete")
  public String delete(@RequestParam("replyno") int replyno,
                       @RequestParam("dogcontno") int dogcontno,
                       Model model) {
    int cnt = this.replyProc.delete(replyno);
    this.replyProc.decreaseReplycnt(dogcontno);

    if (cnt == 1) {
      model.addAttribute("msg", "댓글이 삭제되었습니다.");
    } else {
      model.addAttribute("msg", "댓글 삭제에 실패했습니다.");
    }

    model.addAttribute("url", "/reply/list_by_contentsno?dogcontno=" + dogcontno);
    return "reply/msg";
  }

  /**
   * 댓글 상세 보기
   */
  @GetMapping("/read")
  public String read(@RequestParam("replyno") int replyno, Model model) {
    ReplyVO replyVO = this.replyProc.read(replyno);
    model.addAttribute("replyVO", replyVO);
    return "reply/read";  // calendar 형식의 상세 보기
  }
}
